# filterable-posts-and-custom-post-types
A custom Wordpress widget to display and filter posts and custom post types.
